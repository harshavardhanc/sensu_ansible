export const environment = {
  production: false,
  programId: '5f5f6f66f69c8a0fd28a8aba',
  app_url: "https://diksha.gov.in",
  api_url: "https://projects.diksha.gov.in",
  clientId: "samiksha-ionic-connect",
  environment: "Production",
  kendra_base_url: "https://survey.diksha.gov.in/kendra/api/",
  keyCloak: {
    getAccessToken: "/auth/realms/sunbird/protocol/openid-connect/token",
    redirection_url: "http://localhost:8100/",
    logout_redirect_url: "http://localhost:8100/project-view/home"
  }
};
